# js-learn-along

Learning Javascript

# Things to add

### Basics

<li>Unique employee instantiation</li>
<li>Repair stat management</li>
<i>Art/sprites for employees</i>
<i>Running tally of revenue earned</i>

### Stretch ideas

<li>Date/Time cycles/calendar
  <ul>
    <li>Workers come and go and/or nighttime is skipped</li>
  </ul>
<li>Pizza Fridays</li>
<ul>
  <li>Weekly buff of happiness</li>
  <li>Lose money every week</li>
</ul>
