# js-learn-along

Learning Javascript

# Notes

Revenue per worker = Current income / 10000 + Current Happiness

# Things to do

### Basics

Running tally of profit earned
Game over state. Can't afford state (eg disabled buttons). More price clarity. Balancing. Spritesheets!!!!! Number texts resize based on width. Juicy spend/earn/profit-vs-revenue tracking. Color-coded auras on workers that match their mood. More mobile friendly.

### Stretch ideas

<li>Date/Time cycles/calendar
  <ul>
    <li>Workers come and go and/or nighttime is skipped</li>
  </ul>
<li>Pizza Fridays</li>
<ul>
  <li>Weekly buff of happiness</li>
  <li>Lose money every week</li>
</ul>
